import os
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.preprocessing.image import ImageDataGenerator, load_img, img_to_array

# Step 1: Define folder to save augmented images
save_dir = "augmented_images"

if not os.path.exists(save_dir):
    os.makedirs(save_dir)

# Step 2: Initialize ImageDataGenerator
datagen = ImageDataGenerator(
    rotation_range=40,
    shear_range=0.2,
    zoom_range=0.2,
    horizontal_flip=True,
    brightness_range=[0.5, 1.5],
    fill_mode='nearest'
)

# Step 3: Load your image (CHANGE PATH)
image_path = "task 4 image.jpg"
img = load_img(image_path)
x = img_to_array(img)

# Step 4: Reshape image
x = np.expand_dims(x, axis=0)

# Step 5: Generate 40 augmented images
i = 0
for batch in datagen.flow(
        x,
        batch_size=1,
        save_to_dir=save_dir,
        save_prefix="aug",
        save_format="jpeg"):

    i += 1
    if i >= 40:
        break

print("40 Augmented images saved in folder:", save_dir)